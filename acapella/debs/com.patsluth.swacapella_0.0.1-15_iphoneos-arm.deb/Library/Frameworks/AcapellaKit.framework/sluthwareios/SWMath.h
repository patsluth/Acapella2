//
//  SWMath.h
//  sluthwareioslibrary
//
//  Created by Pat Sluth on 2014-10-26.
//  Copyright (c) 2014 Pat Sluth. All rights reserved.
//

#import <Foundation/Foundation.h>

#define SWDegreesToRadians(x) ((M_PI / 180.0) * x)
#define SWRadiansToDegrees(x) ((180.0 / M_PI) * x)

@interface SWMath : NSObject

@end




