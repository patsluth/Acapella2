//
//  SWAnalytics.h
//  sluthwareios
//
//  Created by Pat Sluth on 2014-03-02.
//  Copyright (c) 2014 Sluthware. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SWAnalytics : NSObject

@end




