//
//  AcapellaKit.h
//  AcapellaKit
//
//  Created by Pat Sluth on 2014-10-26.
//  Copyright (c) 2014 Pat Sluth. All rights reserved.
//

#import <UIKit/UIKit.h>





FOUNDATION_EXPORT double AcapellaKitVersionNumber; //! Project version number for AcapellaKit.
FOUNDATION_EXPORT const unsigned char AcapellaKitVersionString[]; //! Project version string for AcapellaKit.





#import <AcapellaKit/SWAcapellaBase.h>
#import <AcapellaKit/SWAcapellaScrollViewProtocol.h>
#import <AcapellaKit/SWAcapellaTableView.h>
#import <AcapellaKit/SWAcapellaScrollView.h>




